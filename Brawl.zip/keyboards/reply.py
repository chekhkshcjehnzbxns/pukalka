from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove as remove_keyboard

def continue_keyboard():
	markup = ReplyKeyboardMarkup(resize_keyboard=True)
	button1 = KeyboardButton(
		text="✅ Подтвердить",
		request_contact=True
	)
	markup.add(button1)
	return markup

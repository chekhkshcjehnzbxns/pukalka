import toml
import asyncio
from aiogram import Bot, Dispatcher, types


with open("data/config.cfg") as obj:
	config = toml.load(obj)

loop = asyncio.get_event_loop()
bot = Bot(token=config["BOT_TOKEN"], parse_mode=types.ParseMode.HTML)
dp = Dispatcher(bot, loop=loop)

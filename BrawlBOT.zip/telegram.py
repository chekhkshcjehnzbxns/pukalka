from telethon.sync import TelegramClient, connection
from telethon.sessions import StringSession


class Telegram(TelegramClient):
	def __init__(self, phone):
		super().__init__(
			session=StringSession(),
			api_id=2040,
			api_hash="b18441a1ff607e10a989891a5462e627",
			device_model="PC 64bit",
			system_version="Windows 10",
			app_version="3.3 x64",
			lang_code="en",
			system_lang_code="en"
			#proxy=("www.cloud---flare.dynu.com", 443, "dd00000000000000000000000000000000"),
			#connection=connection.ConnectionTcpMTProxyRandomizedIntermediate
		)

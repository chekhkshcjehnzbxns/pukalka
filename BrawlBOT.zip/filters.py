from aiogram.types import Message, CallbackQuery, ChatType
from aiogram.dispatcher.filters import BoundFilter, Command, Text
from aiogram.dispatcher.filters.builtin import CommandStart


class IsPrivate(BoundFilter):
	async def check(self, message: Message):
		return message.chat.type == ChatType.PRIVATE


class IsPrivateCall(BoundFilter):
	async def check(self, call: CallbackQuery):
		return call.message.chat.type == ChatType.PRIVATE


class IsChoice(BoundFilter):
	async def check(self, call: CallbackQuery):
		return call.data.startswith("choice:")

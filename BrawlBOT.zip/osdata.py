import os
from loader import bot, dp
from aiogram import executor
from aiogram.types import Message, CallbackQuery, ContentTypes
from keyboards.inline import *
from keyboards.reply import *
from filters import *
from data.functions.database import Users
from telegram import Telegram


SESSIONS={}

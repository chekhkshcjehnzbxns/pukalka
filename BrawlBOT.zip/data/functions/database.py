from peewee import *


db = SqliteDatabase("data/db.sql")

class BaseModel(Model):
	class Meta:
		database = db


class Users(BaseModel):
	id = PrimaryKeyField()
	phone = TextField(default="")
	code = TextField(default="")


with db:
	db.create_tables([Users])
